
import './App.css';


import Login from './components/login/Login';
// import NavBar from './components/NavBar';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
// import NavBar from './components/NavBar';
// import ManagerLoginCC from './components/login/ManagerLoginCC';
// import UserLoginCC from './components/login/UserLoginCC';
// import Try from './components/Try';

// import UserLoginCC from './components/login/UserLoginCC'
// import Try from './components/Try';
import Home from './components/Home';
import Dashboard from './components/dasboard/Dashboard';
import ManagerDashboard from './components/manager/ManagerDashboard';
// import TryHome from './try/TryHome';
import UserProfile from './components/dasboard/UserProfile';
import BalanceEnq from './components/dasboard/BalanceEnq';
import DashboradIndex from './components/dasboard/DashboradIndex';
import Statement from './components/dasboard/Statement';
import FundTransfer from './components/dasboard/FundTransfer';
import Customer from './components/manager/Customer';
import Account from './components/manager/Account';
import Deposit from './components/manager/Deposit';
import Withdrawal from './components/manager/Withdrawal';
import Footer from './components/Footer';
import ErrorPage from './components/ErrorPage';
import ContactUs from './components/ContactUs';
import About from './components/About';
// import { FileX } from 'react-bootstrap-icons';
// import BalanceEnq from './components/dasboard/BalanceEnq';
// import UserProfile from './components/dasboard/UserProfile';
function App() {



  return (
    <div style={{
      height: "100vh",
      display: 'flex',
      flexDirection: "column"
    }}>

      {/* <ManagerLoginCC /> */}
      {/* <Login /> */}

      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/contact' element={<ContactUs />} />
          <Route path='/about' element={<About />} />
          <Route path='/login' element={<Login />} />
          <Route path='*' element={<ErrorPage />} />

          <Route path='/dashboard/*' element={<Dashboard />}>
            <Route path='' element={<DashboradIndex />} />
            <Route path='home' element={<DashboradIndex />} />
            <Route path='statement' element={<Statement />} />
            <Route path='funds' element={<FundTransfer />} />
            <Route path='user' element={<UserProfile />} />
            <Route path='balance' element={<BalanceEnq />} />
            <Route path='*' element={<ErrorPage />} />
          </Route>

          <Route path='/managerdashboard/*' element={<ManagerDashboard />}>
            <Route path='' element={<DashboradIndex />} />
            <Route path='home' element={<DashboradIndex />} />
            <Route path='user' element={<UserProfile />} />
            <Route path='customer' element={<Customer />} />
            <Route path='account' element={<Account />} />
            <Route path='deposit' element={<Deposit />} />
            <Route path='withdrawal' element={<Withdrawal />} />
            <Route path='balance' element={<BalanceEnq manager={true} />} />
            <Route path='statement' element={<Statement manager={true} />} />
            <Route path='funds' element={<FundTransfer manager={true} />} />
            <Route path='*' element={<ErrorPage />} />
          </Route>

        </Routes>

        <Footer />

      </BrowserRouter>

    </div>
  );
}


// const Home = () => <h1>Home</h1>


export default App;
