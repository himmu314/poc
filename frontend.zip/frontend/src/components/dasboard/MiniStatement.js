import React, { useState, useEffect } from 'react'
import { getMiniStatement, accountById, accountsByUserId, checkAccountsByUserId } from '../helpers/AccountHelper'
import LoadingFC from '../helpers/LoadingFC';

export default function MiniStatement(props) {

  let [accountNo, setAccountNo] = useState('')
  let [transactions, setTransactions] = useState([])
  let [visible, setVisible] = useState(false)
  let [cusVisible, setCusVisible] = useState(false)
  let [customer, setCustomer] = useState([])
  let [accountType, setAccountType] = useState("Saving")

  let Customer =
    cusVisible ?
      <div>
        <select className="form-select mb-3" aria-label="Default select example" required defaultValue={accountType}
          onChange={(e) => setAccountType(e.target.value)}>
          <option value="Saving">Saving</option>
          <option value="Current">Current</option>
        </select>

        <select className="form-select mb-3" aria-label="Default select example" required
          onChange={(e) => setAccountNo(e.target.value)} >
          {
            customer.map((account) => {
              return <option key={account.accountNo} value={account.accountNo}>{account.accountNo}</option>
            })
          }
        </select>
      </div>
      :
      <LoadingFC />

  let Manager =
    <div className='col-md-12 mb-4'>
      <input type="text" placeholder='Enter Account No' className='form-control' required
        value={accountNo} onChange={(e) => setAccountNo(e.target.value)} />
    </div>

  let TRANSACTIONS =
    <div className='col-12 mt-5'>
      <h4 className='mb-4 text-center text-warning fw-bold'>Transactions</h4>
      <hr />
      <table className='table table-striped table-hover border rounded'>
        <tbody>
          <tr>
            <th>Trans ID</th>
            <th>Date</th>
            <th>Description</th>
            <th>Amount</th>
            <th>Balance</th>
          </tr>

          {
            transactions.map((transaction) => {
              return <tr key={transaction.transactionId} >
                <td key='1'>{transaction.transactionId}</td>
                <td key='2'>{transaction.date.substring(0, 10)}</td>
                <td key='3'>{transaction.description}<h6>{transaction.transactionType}</h6></td>
                <td key='4'>{transaction.amount}</td>
                <td key='5'>{transaction.totalAmount}</td>
              </tr>

            })
          }
        </tbody>
      </table>
    </div >


  useEffect(() => {
    if (customer.length !== 0) {
      setCusVisible(true)
      setAccountNo(customer[0].accountNo)
    }

  }, [customer])

  useEffect(() => {
    (async function fetchData() {
      let data = await accountsByUserId(localStorage.getItem("id"), accountType)
      setCustomer(data)
    })()
  }, [accountType])

  async function customerfun() {
    let data = await accountsByUserId(localStorage.getItem("id"), accountType)
    if (data.length === 0) {
      setAccountType("Current")
      data = await accountsByUserId(localStorage.getItem("id"), "Current")
    }
    setCustomer(data)
  }


  let [checked, setChecked] = useState(false)
  let [accountAvailable, setAccountAvailable] = useState(false)

  async function checkUserAccount() {
    var data = await checkAccountsByUserId(localStorage.getItem("id"))
    setAccountAvailable(data)
    setChecked(true)
  }


  if (props.manager === false) {

    if (checked === false)
      checkUserAccount()

    if (customer.length === 0 && checked === false)
      customerfun()
  }

  useEffect(() => {
    if (transactions !== null && transactions.length !== 0)
      setVisible(true)
  }, [transactions])

  async function handleSubmit(e) {
    e.preventDefault()

    setTransactions([])
    setVisible(false)

    if (accountNo === '')
      alert("Choose Account No.")
    else {
      var accountData = await accountById(accountNo)
      if (accountData === null)
        alert("Invalid Account Number.")
      else {
        var data = await getMiniStatement(accountNo)
        if (data == null)
          alert("No Transactions Available.")
        else {
          setTransactions(data)
        }
      }
    }

  }

  function resetPage() {
    setAccountNo('')
    setTransactions([])
    setVisible(false)
    setCustomer([])
    setAccountType("Saving")
  }

  return (
    <div>
      {
        props.manager === true || accountAvailable ?
          <div>
            <form className='text-center' onSubmit={handleSubmit} onReset={resetPage} >
              <div className='text-success mb-4'>
                <h3>Mini Statement</h3>
              </div>

              {props.manager ? Manager : Customer}

              <div className='row m-2'>
                <div className='col-6 text-center'>
                  <input type="submit" className="btn btn-success" value="Submit" />
                </div>
                <div className='col-6 text-center'>
                  <input type="reset" className="btn btn-success" value="Reset" />
                </div>
              </div>
            </form>

            {visible ? TRANSACTIONS : null}
          </div>
          :
          <div>
            <h3 className='text-center text-danger'>No Accounts Available</h3>
          </div>
      }


    </div>
  )
}


MiniStatement.defaultProps = {
  manager: false
}