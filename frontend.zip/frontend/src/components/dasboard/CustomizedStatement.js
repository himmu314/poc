import React, { useState, useEffect } from 'react'
import { accountById, getCustomizeStatement, accountsByUserId, checkAccountsByUserId } from '../helpers/AccountHelper'
import LoadingFC from '../helpers/LoadingFC';

export default function CustomizedStatement(props) {

  let [statementData, setStatementData] = useState({
    accountNo: '',
    fromDate: '',
    toDate: '',
    lowerLimit: '',
    noOfTransactions: ''
  })

  let [transactions, setTransactions] = useState([])
  let [visible, setVisible] = useState(false)
  let [cusVisible, setCusVisible] = useState(false)
  let [customer, setCustomer] = useState([])
  let [accountType, setAccountType] = useState("Saving")


  let Customer =
    cusVisible ?
      <div className='row'>
        <select className="form-select mb-3" aria-label="Default select example" required defaultValue={accountType}
          onChange={(e) => setAccountType(e.target.value)}>
          <option value="Saving">Saving</option>
          <option value="Current">Current</option>
        </select>

        <select className="form-select mb-3" aria-label="Default select example" required
          onChange={(e) => setStatementData({ ...statementData, accountNo: e.target.value })} >
          {
            customer.map((account) => {
              return <option key={account.accountNo} value={account.accountNo}>{account.accountNo}</option>
            })
          }
        </select>
      </div>
      :
      <LoadingFC />


  let Manager =
    <div className='col-md-12 mb-4'>
      <input type="text" placeholder='Enter Account No' className='form-control' required
        value={statementData.accountNo}
        onChange={(e) => setStatementData({ ...statementData, accountNo: e.target.value })} />
    </div>



  let TRANSACTIONS =
    <div className='col-12 mt-5'>
      <h4 className='mb-4 text-center text-warning fw-bold'>Transactions</h4>
      <hr />
      <table className=' table table-striped table-hover  border rounded'>
        <tbody>
          <tr>
            <th>Trans ID</th>
            <th>Date</th>
            <th>Description</th>
            <th>Amount</th>
            <th>Balance</th>
          </tr>

          {
            transactions.map((transaction) => {
              return <tr key={transaction.transactionId} >
                <td key='1'>{transaction.transactionId}</td>
                <td key='2'>{transaction.date.substring(0, 10)}</td>
                <td key='3'>{transaction.description}<h6>{transaction.transactionType}</h6></td>
                <td key='4'>{transaction.amount}</td>
                <td key='5'>{transaction.totalAmount}</td>
              </tr>

            })
          }
        </tbody>
      </table>
    </div >



  useEffect(() => {
    if (customer.length !== 0) {
      setCusVisible(true)
      setStatementData({ ...statementData, accountNo: customer[0].accountNo })
    }
    // eslint-disable-next-line
  }, [customer])

  useEffect(() => {
    (async function fetchData() {
      let data = await accountsByUserId(localStorage.getItem("id"), accountType)
      setCustomer(data)
    })()
  }, [accountType])

  async function customerfun() {
    let data = await accountsByUserId(localStorage.getItem("id"), accountType)
    if (data.length === 0) {
      setAccountType("Current")
      data = await accountsByUserId(localStorage.getItem("id"), "Current")
    }
    setCustomer(data)
  }


  let [checked, setChecked] = useState(false)
  let [accountAvailable, setAccountAvailable] = useState(false)

  async function checkUserAccount() {
    var data = await checkAccountsByUserId(localStorage.getItem("id"))
    setAccountAvailable(data)

    setChecked(true)
  }


  if (props.manager === false) {

    if (checked === false)
      checkUserAccount()

    if (customer.length === 0 && checked === false)
      customerfun()
  }



  useEffect(() => {
    if (transactions !== null && transactions.length !== 0)
      setVisible(true)
  }, [transactions])

  async function handleSubmit(e) {
    e.preventDefault()

    setTransactions([])
    setVisible(false)

    if (statementData.accountNo === '')
      alert("Choose Account No.")
    else {

      var accountData = await accountById(statementData.accountNo)
      if (accountData === null)
        alert("Invalid Account Number.")
      else {
        var data = await getCustomizeStatement(statementData)
        if (data == null)
          alert("No Transactions Available.")
        else {
          setTransactions(data)
        }
      }


    }

  }

  function resetPage() {
    setStatementData({
      accountNo: '',
      fromDate: '',
      toDate: '',
      lowerLimit: '',
      noOfTransactions: ''
    })
    setTransactions([])
    setVisible(false)
    setCustomer([])
    setAccountType("Saving")
  }



  return (
    <div>
      {
        props.manager === true || accountAvailable ?
          <div>
            <form className='row gy-3' onSubmit={handleSubmit} onReset={resetPage} >
              <div className='text-center text-success mb-3 mt-5'>
                <h3>Customized Statement</h3>
              </div>

              {props.manager ? Manager : Customer}

              <div className='col-md-6'>
                <label className='form-label'>From Date</label>
                <input type="date" className='form-control' required
                  value={statementData.fromDate}
                  onChange={(e) => setStatementData({ ...statementData, fromDate: e.target.value })} />
              </div>

              <div className='col-md-6'>
                <label className='form-label'>To Date</label>
                <input type="date" className='form-control' required
                  value={statementData.toDate}
                  onChange={(e) => setStatementData({ ...statementData, toDate: e.target.value })} />
              </div>

              <div className='col-md-6'>
                <label className='form-label'>Amount Lower Limit</label>
                <input type="text" className='form-control' required pattern='[0-9]{1,}' title='Enter Only Numbers'
                  value={statementData.lowerLimit}
                  onChange={(e) => setStatementData({ ...statementData, lowerLimit: e.target.value })} />
              </div>

              <div className='col-md-6'>
                <label className='form-label'>Number Of Transaction</label>
                <input type="text" className='form-control' required pattern='[0-9]{1,}' title='Enter Only Numbers'
                  value={statementData.noOfTransactions}
                  onChange={(e) => setStatementData({ ...statementData, noOfTransactions: e.target.value })} />
              </div>


              <div className='col-6 text-center'>
                <input type="submit" className="btn btn-success" value="Submit" />
              </div>
              <div className='col-6 text-center'>
                <input type="reset" className="btn btn-success" value="Reset" />
              </div>



            </form>

            {visible ? TRANSACTIONS : null}

          </div>
          :
          <div className='my-4'>
            <h3 className='text-center text-danger'>No Accounts Available</h3>
          </div>
      }

    </div>
  )
}


CustomizedStatement.defaultProps = {
  manager: false
}