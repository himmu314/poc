import React from 'react'
import userPic from "../../images/profile.webp"
import { useNavigate } from 'react-router-dom';


export default function UserDetails() {
  let navigate = useNavigate();

  function logout() {
    alert("Logout Successfully.");
    localStorage.removeItem("id")
    localStorage.removeItem("name")
    localStorage.removeItem("userRole")
    navigate("/")
  }

  return (
    <div className='bg-white'>

      <div className='container p-1'>
        <div className='row'>
          <div className='col-6'>
            <img src={userPic} alt='User Pic' style={{ width: "1.5rem" }} className="rounded-circle shadow" />
            <span className='ps-4'>{localStorage.getItem("name")}</span>
          </div>
          <div className='col-6'>
            <button className='btn btn-danger btn-sm float-end' onClick={logout}>Logout</button>
          </div>
        </div>

      </div>
    </div>
  )
}
