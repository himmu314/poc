import React, { useState, useEffect } from 'react'
import { accountsByUserId, balanceEnquiry, checkAccountsByUserId } from '../helpers/AccountHelper'
import LoadingFC from '../helpers/LoadingFC';


export default function BalanceEnq(props) {

  let [accountNo, setAccountNo] = useState('')
  let [visible, setVisible] = useState(false)
  let [customer, setCustomer] = useState([])
  let [accountType, setAccountType] = useState("Saving")
  let [accountAvailable, setAccountAvailable] = useState(false)

  let Customer =
    visible ?
      <div>
        <select className="form-select mb-3" aria-label="Default select example" required defaultValue={accountType}
          onChange={(e) => setAccountType(e.target.value)}>
          <option value="Saving">Saving</option>
          <option value="Current">Current</option>
        </select>

        <select className="form-select mb-3" aria-label="Default select example" required
          onChange={(e) => setAccountNo(e.target.value)} >
          {
            customer.map((account) => {
              return <option key={account.accountNo} value={account.accountNo}>{account.accountNo}</option>
            })
          }
        </select>
      </div>
      :
      <LoadingFC />

  let Manager =
    <div className='col-md-12 mb-3'>
      <input type="text" placeholder='Enter Account No' className='form-control' required
        value={accountNo}
        onChange={(e) => setAccountNo(e.target.value)} />
    </div>


  useEffect(() => {
    if (customer.length !== 0) {
      setVisible(true)
      setAccountNo(customer[0].accountNo)
    }

  }, [customer])

  useEffect(() => {
    (async function fetchData() {
      var data = await accountsByUserId(localStorage.getItem("id"), accountType)
      setCustomer(data)
    })()
  }, [accountType])

  async function customerfun() {
    var data = await accountsByUserId(localStorage.getItem("id"), accountType)
    if (data.length === 0) {
      setAccountType("Current")
      data = await accountsByUserId(localStorage.getItem("id"), "Current")
    }
    setCustomer(data)
  }

  let [checked, setChecked] = useState(false)

  async function checkUserAccount() {
    var data = await checkAccountsByUserId(localStorage.getItem("id"))
    setAccountAvailable(data)
    setChecked(true)
  }

  if (props.manager === false) {

    if (checked === false)
      checkUserAccount()

    if (customer.length === 0 && checked === false)
      customerfun()

  }

  let [isBalanceVisible, setIsBalanceVisible] = useState(false)
  let [accountBalance, setAccountBalance] = useState('')

  async function handleSubmit(e) {
    e.preventDefault()

    if (accountNo === '')
      alert("Choose Account No.")
    else {
      var balance = await balanceEnquiry(accountNo)
      if (balance == null)
        alert("Invalid Account Number.")
      else {
        setAccountBalance(balance)
        setIsBalanceVisible(true)

      }
    }

  }

  function resetPage() {
    setAccountNo('')
    setCustomer([])
    setAccountType("Saving")
    setIsBalanceVisible(false)
    setAccountBalance('')
  }

  return (
    <div className='container'>

      <div className='row g-0 justify-content-md-center mt-5'>

        <div className='col-md-8 bg-light rounded p-4'>
          {
            props.manager === true || accountAvailable ?
              <form className='text-center' onSubmit={handleSubmit} onReset={resetPage} >
                <div className='text-success mb-4'>
                  <h2>Balance Enquiry</h2>
                </div>


                {props.manager ? Manager : Customer}

                {
                  isBalanceVisible ?
                    <div className='text-center mb-3'>
                      <h5>Balance: <span className='text-primary'>{accountBalance}</span></h5>
                    </div>
                    :
                    null
                }

                {
                  props.manager === true || visible ?
                    <div className='row m-2'>
                      <div className='col-6 text-center'>
                        <input type="submit" className="btn btn-success" value="Submit" />
                      </div>
                      <div className='col-6 text-center'>
                        <input type="reset" className="btn btn-success" value="Reset" />
                      </div>
                    </div>
                    :
                    null

                }


              </form>
              :
              <div>
                <h3 className='text-center text-danger'>No Accounts Available</h3>
              </div>
          }

        </div>

      </div>

    </div>
  )
}

BalanceEnq.defaultProps = {
  manager: false
}