import React from 'react'
import leftPic from '../../images/inner.svg'
// import rightPic from '../../images/bank.svg'

export default function DashboradIndex() {
  return (
    <div className='container'>

      <h1 className='text-center mt-4 text-white display-5' >Welcome To <strong>XOR-Bank</strong></h1>
      <hr className='text-white border border-1'/>

      <div className='row mt-3 gy-3'>
        
        <div className='col-md-6'>
          <h1 className='text-white display-3'>Banking & Budgeting, made simple</h1>
          
        </div>

        <div className='col-md-6'>
           <img src={leftPic} alt='Banking Pic' className='img-fluid w-75 mt-5' />
        </div>


      </div>
        
    </div>
  )
}
