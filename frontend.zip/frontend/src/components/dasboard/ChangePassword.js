import React, { useState } from 'react'
import { Collapse } from 'react-bootstrap';
import { updatePassword } from '../helpers/User';

export default function ChangePassword() {

    let [collapseMenu, setCollapseMenu] = useState(true)
    let [visible, setVisible] = useState(false)
    let [passwordMatch, setPasswordMatch] = useState(false)

    let [userData, setUserData] = useState({
        oldPassword: '',
        newPassword: '',
        userId: localStorage.getItem("id")
    })

    let [confirmPassword, setConfirmPassword] = useState('')

    function showHide(e) {
        e.preventDefault();
        setCollapseMenu(!collapseMenu)
        resetPage()
    }


    function checkPassword(e) {
        setVisible(true)

        setConfirmPassword(e.target.value)
        if (userData.newPassword !== e.target.value) {
            setPasswordMatch(false)
        }
        else
            setPasswordMatch(true)
    }


    async function handleSubmit(e) {

        e.preventDefault()

        if (userData.newPassword === confirmPassword) {
            var data = await updatePassword(userData)
            if (data === false)
                alert("Password Is incorrect.")
            else {
                alert("Password Updated Successfully")
                setCollapseMenu(!collapseMenu)
                resetPage()
            }
        }
        else
            alert("Password is not matching.")


    }

    function resetPage() {
        setUserData({
            oldPassword: '',
            newPassword: '',
            userId: localStorage.getItem("id")
        })
        setConfirmPassword('')
        setPasswordMatch(false)
        setVisible(false)
    }

    return (
        <div>

            <p>
                <button className="btn btn-primary" type="button" onClick={showHide} data-bs-toggle="collapse" data-bs-target="#collapse" aria-expanded="false" aria-controls="collapse">
                    Change Password
                </button>
            </p>
            <Collapse in={!collapseMenu}>
                <div className="card card-body bg-light mb-3">

                    <div className='row justify-content-md-center mt-2'>
                        <div className='col-md-6 rounded p-3'>

                            <form className='row gy-3' onSubmit={handleSubmit} onReset={resetPage}>
                                <div className='text-center text-success my-3'>
                                    <h3>Change Password</h3>
                                </div>


                                <div className='col-md-12'>
                                    <label className='form-label'>Old Password</label>
                                    <input type="password" className='form-control' required
                                        value={userData.oldPassword}
                                        onChange={(e) => setUserData({ ...userData, oldPassword: e.target.value })} />
                                </div>

                                <div className='col-md-12'>
                                    <label className='form-label'>New Password</label>
                                    <input type="password" className='form-control' required
                                        value={userData.newPassword}
                                        onChange={(e) => setUserData({ ...userData, newPassword: e.target.value })} />

                                </div>
                                <div className='col-md-12'>
                                    <label className='form-label'>Confirm Password</label>
                                    <input type="password" className='form-control' required
                                        value={confirmPassword}
                                        onChange={checkPassword} />
                                    {
                                        visible ?
                                            <div>
                                                {
                                                    passwordMatch ?
                                                        <div className='text-success'><p>Password Matched</p></div>
                                                        :
                                                        <div className='text-danger'><p>Password is not matched</p></div>
                                                }
                                            </div>
                                            :
                                            null
                                    }

                                </div>

                                <div className='col-6 text-center'>
                                    <input type="submit" className="btn btn-success mt-2" value="Submit" />
                                </div>
                                <div className='col-6 text-center'>
                                    <input type="reset" className="btn btn-success mt-2" value="Reset" />
                                </div>
                            </form>

                        </div>
                    </div>

                </div>
            </Collapse>

        </div>
    )
}
