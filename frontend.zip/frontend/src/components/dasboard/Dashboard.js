import React from 'react'
import { Outlet, Link } from 'react-router-dom'
import InnerNavBar from '../navigation/InnerNavBar'

import UserDetails from './UserDetails'

export default function Dashboard() {

  function logout() {
    localStorage.removeItem("id")
    localStorage.removeItem("name")
    localStorage.removeItem("userRole")
  }


  let Result = null


  const TRUE =
    <div className='mb-5'>
      <InnerNavBar />
      <UserDetails />
      <Outlet />
    </div>

  const FALSE =
    <div className='text-center text-white mt-5'>
      <h1>
        You are not login. Please login to view this page.
      </h1>
      <p>Go To Login Page <Link to="/login" onClick={logout} >Click here...</Link></p>
    </div>

  if (localStorage.getItem("userRole") === "Customer")
    Result = TRUE
  else
    Result = FALSE

  return (

    Result
  )

}
