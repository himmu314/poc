import { useState, useEffect } from "react"
import React from 'react'
import { accountById, transferFunds, accountsByUserId, checkAccountsByUserId } from "../helpers/AccountHelper"
import LoadingFC from '../helpers/LoadingFC';

export default function FundTransfer(props) {

  let [fundsTransfer, setFundTransfer] = useState({
    ownAccountNo: '',
    payeesAccountNo: '',
    amount: ''
  })

  let [cusVisible, setCusVisible] = useState(false)
  let [customer, setCustomer] = useState([])
  let [accountType, setAccountType] = useState("Saving")



  let Customer =
    cusVisible ?
      <div>
        <select className="form-select mb-3" aria-label="Default select example" required defaultValue={accountType}
          onChange={(e) => setAccountType(e.target.value)}>
          <option value="Saving">Saving</option>
          <option value="Current">Current</option>
        </select>

        <select className="form-select mb-3" aria-label="Default select example" required
          onChange={(e) => setFundTransfer({ ...fundsTransfer, ownAccountNo: e.target.value })}  >
          {
            customer.map((account) => {
              return <option key={account.accountNo} value={account.accountNo}>{account.accountNo}</option>
            })
          }
        </select>
      </div>
      :
      <LoadingFC />
  let Manager =
    <div className='col-md-12 mb-4'>
      <input type="text" placeholder='Enter Account No' className='form-control' required
        value={fundsTransfer.ownAccountNo}
        onChange={(e) => setFundTransfer({ ...fundsTransfer, ownAccountNo: e.target.value })} />
    </div>




  useEffect(() => {
    if (customer.length !== 0) {
      setCusVisible(true)
      setFundTransfer({ ...fundsTransfer, ownAccountNo: customer[0].accountNo })
    }
    // eslint-disable-next-line
  }, [customer])

  useEffect(() => {
    (async function fetchData() {
      let data = await accountsByUserId(localStorage.getItem("id"), accountType)
      setCustomer(data)
    })()
  }, [accountType])

  async function customerfun() {
    let data = await accountsByUserId(localStorage.getItem("id"), accountType)
    if (data.length === 0) {
      setAccountType("Current")
      data = await accountsByUserId(localStorage.getItem("id"), "Current")
    }
    setCustomer(data)
  }

  let [checked, setChecked] = useState(false)
  let [accountAvailable, setAccountAvailable] = useState(false)

  async function checkUserAccount() {
    var data = await checkAccountsByUserId(localStorage.getItem("id"))
    setAccountAvailable(data)
    setChecked(true)
  }


  if (props.manager === false) {

    if (checked === false)
      checkUserAccount()

    if (customer.length === 0 && checked === false)
      customerfun()
  }




  async function handleSubmit(e) {
    e.preventDefault()

    var ownAccount = await accountById(fundsTransfer.ownAccountNo)
    if (ownAccount == null)
      alert("Invalid Sender Account No.")
    else {
      var payeeAccount = await accountById(fundsTransfer.payeesAccountNo)
      if (payeeAccount == null)
        alert("Invalid Payee Account No.")
      else {
        var balance = await transferFunds(fundsTransfer)
        if (balance == null)
          alert("Insufficient Account Balance")
        else {
          alert("Fund Transfer Successfully. Your balance is: " + balance)
          resetPage()
        }
      }
    }
  }

  function resetPage() {
    setFundTransfer({
      ownAccountNo: '',
      payeesAccountNo: '',
      amount: ''
    })
    setCustomer([])
    setAccountType("Saving")

  }




  return (
    <div className='container' >
      <div className='row justify-content-md-center mt-5'>
        <div className='col-md-8 bg-light rounded p-4'>
          {
            props.manager === true || accountAvailable ?

              <form className='row gy-3' onSubmit={handleSubmit} onReset={resetPage}>
                <div className='text-center text-success my-3'>
                  <h3>Fund Transfer</h3>
                </div>

                {props.manager ? Manager : Customer}

                <div className='col-md-12'>
                  <label className='form-label'>Payees Account No</label>
                  <input type="text" className='form-control' required pattern='[0-9]{1,}' title='Enter Only Numbers'
                    value={fundsTransfer.payeesAccountNo}
                    onChange={(e) => setFundTransfer({ ...fundsTransfer, payeesAccountNo: e.target.value })} />
                </div>

                <div className='col-md-12'>
                  <label className='form-label'>Amount</label>
                  <input type="text" className='form-control' required pattern='[0-9]{1,}' title='Enter Only Numbers'
                    value={fundsTransfer.amount}
                    onChange={(e) => setFundTransfer({ ...fundsTransfer, amount: e.target.value })} />
                </div>

                <div className='col-6 text-center'>
                  <input type="submit" className="btn btn-success" value="Submit" />
                </div>
                <div className='col-6 text-center'>
                  <input type="reset" className="btn btn-success" value="Reset" />
                </div>
              </form>
              :
              <div className='my-4'>
                <h3 className='text-center text-danger'>No Accounts Available</h3>
              </div>
          }
        </div>
      </div>
    </div>
  )
}

FundTransfer.defaultProps = {
  manager: false
}