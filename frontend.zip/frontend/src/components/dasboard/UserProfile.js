import React, { useEffect, useState } from 'react'
import userPic from '../../images/profile.webp'
import LoadingFC from '../helpers/LoadingFC';
import { customerData, managerData } from '../helpers/User';
import ChangePassword from './ChangePassword';

export default function UserProfile() {

  let [loading, setLoading] = useState(true)
  let [user, setUser] = useState(null);

  

  useEffect(()=>{
  (async function fetchData(){
    let data
    if(localStorage.getItem("userRole")==="Manager")
      data = await managerData()
    else
      data = await customerData()

    await setUser(data)
  })()
  },[])

  useEffect(()=>{
      if(user!==null)
        setLoading(false);
      //console.log(user)
  },[user]);

  let MANAGER = ""
   if(localStorage.getItem("userRole")==="Manager" && loading===false)
        MANAGER = <div className='row mt-3 justify-content-center'>
                        <div className='col-4'><strong>BRANCH:</strong></div>
                        <div className='col-6 text-danger fw-bold'>{user.branch}</div>
                      </div>
                      


  return (
    loading ? 
      <LoadingFC/>
    :
    <div>
        <div className="my-5 container">
          <div className="row justify-content-center mb-4">
            <div className="col-md-8 bg-white pt-3 px-3 pb-1 rounded">
              <div className="row justify-content-center mb-4 gy-3">
                <div className="col-md-3 text-center">
                  <img src={userPic} className="img-fluid rounded-start p-3 mt-3" style={{width: "10rem"}} alt="User Pic" />
                   <h4 className="text-center">{user.userName}</h4>
                </div>
                <div className="col-md-7">
                  <div className="card-body">
                   
                    
                      <div className='row justify-content-center'>
                        <div className='col-4'><strong>Gender:</strong></div>
                        <div className='col-6'>{user.gender}</div>
                      </div>
                      <div className='row  justify-content-center'>
                        <div className='col-4'><strong>DOB</strong></div>
                        <div className='col-6'>{user.dob.substring(0,10)}</div>
                      </div>
                      <div className='row justify-content-center'>
                        <div className='col-4'><strong>Address:</strong></div>
                        <div className='col-6'>{user.address.streetName}</div>
                      </div>
                      <div className='row justify-content-center'>
                        <div className='col-4'><strong>City:</strong></div>
                        <div className='col-6'>{user.address.city}</div>
                      </div>
                      <div className='row justify-content-center'>
                        <div className='col-4'><strong>State:</strong></div>
                        <div className='col-6'>{user.address.state}</div>
                      </div>
                      <div className='row justify-content-center'>
                        <div className='col-4'><strong>PIN:</strong></div>
                        <div className='col-6'>{user.address.pin}</div>
                      </div>
                      <div className='row justify-content-center'>
                        <div className='col-4'><strong>Telephone:</strong></div>
                        <div className='col-6'>{user.telNo}</div>
                      </div>
                      <div className='row justify-content-center'>
                        <div className='col-4'><strong>Email:</strong></div>
                        <div className='col-6'>{user.email}</div>
                      </div>

                      {MANAGER}  

                  </div>
                </div>

                
              </div>

            <ChangePassword/>
            </div>
          
          </div>
        </div>
    </div>
    
  )


}
