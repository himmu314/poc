import React from 'react'
import { Link } from 'react-router-dom'

export default function ErrorPage() {
  return (
    <div className='text-center text-white '>
      <h1 className='mt-5' >404 Page Not Found</h1>
      <p>Click here to <Link to="/" >Go Back...</Link></p>
    </div>
  )
}
