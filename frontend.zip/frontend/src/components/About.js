import React from 'react'
import OuterNavBar from './navigation/OuterNavBar'
import about from '../images/about.svg'

export default function About() {
  return (
    <div>
        
        <OuterNavBar/>

        <div className='container'>
            <h1 className='mt-5 text-center text-warning display-5 fw-bold'>About Us</h1>
            
            <div className='row mt-5 gx-5 gy-4 mb-5'>
                <div className='col-md-6'>
                    <img src={about} alt="About Us" className='img-fluid' />
                </div>
                <div className='col-md-6 text-white'>
                     <h2 className='text-white'>We Solve Your Financial Problem</h2>
                     <hr/>
                        <p className='fw-bold fst-italic'>
                        XOR Bank is one of India’s leading private banks and was among the first to receive approval from the Reserve Bank of India (RBI) to set up a private sector bank in 1994.
                        Today, XOR Bank has a banking network of 6,378 branches and 18,620 ATM's in 3,203 cities/towns.
                        </p>
                </div>
            </div>
            

           
        </div>
        
    </div>
  )
}
