import React from 'react'

export default function Footer() {
  return (
    <footer className="py-3 mt-auto" style={{backgroundColor: "rgb(20, 32, 62)"}}>

  <div className="container">
    <div className="row d-flex justify-content-center">
      <div className="col-md-6">

      </div>
    </div>
  </div>
  
  <div className="footer-copyright text-center text-white">© 2022 Copyright:
   XORBank.com
  </div>

</footer>

  )
}
