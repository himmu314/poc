import React from 'react'
// import Login from './login/Login'
// import { Outlet } from 'react-router-dom';
// import NavBar from './NavBar';
import OuterNavBar from './navigation/OuterNavBar';


export default function Home() {
  return (
    <div className='mb-5'>

        <OuterNavBar />
        
        <div className='container mt-5'>

          <div className='row'>

            <div className='col-md-6 text-white'>
              <h1 className='display-3'>The most transparent & security banking ever</h1>
              <hr className='border border-2' />
              <p className='fw-bold fst-italic p-3 rounded mt-3'>Open an account and get the best class facilities with amazing offers. Open account in just few minutes.</p>
              {/* <button className='btn btn-danger rounded-pill shadow'>Get Started</button> */}
            </div>
          </div>

        </div>
        


    </div>
  )
}
