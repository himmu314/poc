import React from 'react'
import { Navbar,Nav} from 'react-bootstrap'
import {Link, useLocation} from 'react-router-dom';
import logo from '../../images/logo1.png'



export default function OuterNavBar() {

 
 let loc = useLocation()

    return (
      <div>
                    <Navbar style={{backgroundColor: "rgb(20, 32, 84)"}} variant={"dark"} expand="lg" className='ps-4 pe-5'>
                        <Navbar.Brand>
                          <Nav.Link as={Link} to="/">
                          <img src={logo} alt='logo' style={{ width: "5rem" }} />
                          </Nav.Link>
                          </Navbar.Brand>
                          <Navbar className='ms-4'>
                            <h5 className='text-white'>XOR Bank</h5>
                          </Navbar>
                        <Navbar.Toggle aria-controls="navbarScroll" />
                        <Navbar.Collapse id="navbarScroll">
                            <Nav
                                className="ms-auto my-1 my-lg-0"
                                style={{ maxHeight: '100px' }}
                                navbarScroll
                            >
                                <Nav.Link as={Link} className={loc.pathname==="/" ? "active": "" } to="/">Home</Nav.Link>
                               
                                <Nav.Link as={Link} className={loc.pathname==="/login" ? "active": "" } to="/login">Login</Nav.Link>
                                
                                <Nav.Link as={Link} className={loc.pathname==="/about" ? "active": "" } to="/about">About</Nav.Link>
                                
                                <Nav.Link as={Link} className={loc.pathname==="/contact" ? "active": "" } to="/contact">Contact Us</Nav.Link>

                            </Nav>

                        </Navbar.Collapse>
                    </Navbar>
      </div>
    )
}
