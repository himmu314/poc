
export const loginUser = async (data) => {
   //   console.log(data);
   const res = await fetch("http://localhost:8080/api/v1/user/", {
      method: "POST",
      headers: {
         "Content-Type": "application/json",
         'Accept': 'application/json',
         'Access-Control-Allow-Origin': '*',
         'Access-Control-Allow-Credentials': 'true'
      },
      body: JSON.stringify(data)
   });

   try {
      return await res.json();
   }
   catch (error) {
      return null;
   }

}



export const updatePassword = async (data) => {
   //   console.log(data);
   const res = await fetch("http://localhost:8080/api/v1/user/update_password", {
      method: "PUT",
      headers: {
         "Content-Type": "application/json",
         'Accept': 'application/json',
         'Access-Control-Allow-Origin': '*',
         'Access-Control-Allow-Credentials': 'true'
      },
      body: JSON.stringify(data)
   });

   try {
      return await res.json();
   }
   catch (error) {
      return null;
   }

}


export const managerData = async () => {
   const res = await fetch("http://localhost:8080/api/v1/manager/" + localStorage.getItem("id"));

   try {
      //console.log(await res.json())
      return await res.json();
   }
   catch (error) {
      return null;
   }
}


export const customerData = async () => {
   const res = await fetch("http://localhost:8080/api/v1/customer/" + localStorage.getItem("id"));

   try {
      //console.log(await res.json())
      return await res.json();
   }
   catch (error) {
      return null;
   }
}


export const addCustomer = async (data) => {
   //   console.log(data);
   const res = await fetch("http://localhost:8080/api/v1/customer/", {
      method: "POST",
      headers: {
         "Content-Type": "application/json",
         'Accept': 'application/json',
         'Access-Control-Allow-Origin': '*',
         'Access-Control-Allow-Credentials': 'true'
      },
      body: JSON.stringify(data)
   });

   try {
      return await res.json();
   }
   catch (error) {
      return null;
   }

}

export const customerById = async (customerId) => {
   const res = await fetch("http://localhost:8080/api/v1/customer/" + customerId);

   try {
      //console.log(await res.json())
      return await res.json();
   }
   catch (error) {
      return null;
   }
}


export const updateCustomer = async (data) => {
   //   console.log(data);
   const res = await fetch("http://localhost:8080/api/v1/customer/", {
      method: "PUT",
      headers: {
         "Content-Type": "application/json",
         'Accept': 'application/json',
         'Access-Control-Allow-Origin': '*',
         'Access-Control-Allow-Credentials': 'true'
      },
      body: JSON.stringify(data)
   });

   try {
      return await res.json();
   }
   catch (error) {
      return null;
   }

}



export const deleteCustomer = async (customerID) => {
   //   console.log(data);
   const res = await fetch("http://localhost:8080/api/v1/customer/" + customerID, {
      method: "DELETE",
      headers: {
         "Content-Type": "application/json",
         'Accept': 'application/json',
         'Access-Control-Allow-Origin': '*',
         'Access-Control-Allow-Credentials': 'true'
      }
   });

   try {
      return await res.json();
   }
   catch (error) {
      return null;
   }

}
