import React from 'react'

export default function LoadingFC() {
  return (
    <div className='container mt-5'>
        <div className='row justify-content-center'>
            <div className='col-md-6 bg-white rounded p-4 text-center'>
                <h3>Loading...</h3>
            </div>
        </div>
    </div>
  )
}
