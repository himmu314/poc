export const addAccount = async (data) => {
    //   console.log(data);
    const res = await fetch("http://localhost:8080/api/v1/account/", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            'Accept': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify(data)
    });

    try {
        return await res.json();
    }
    catch (error) {
        return null;
    }

}


export const accountById = async (accountNo) => {
    //   console.log(data);
    const res = await fetch("http://localhost:8080/api/v1/account/" + accountNo);

    try {
        return await res.json();
    }
    catch (error) {
        return null;
    }

}


export const updateAccount = async (data) => {
    //   console.log(data);
    const res = await fetch("http://localhost:8080/api/v1/account/", {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            'Accept': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify(data)
    });

    try {
        return await res.json();
    }
    catch (error) {
        return null;
    }

}

export const deleteAccount = async (accountNo) => {
    //   console.log(data);
    const res = await fetch("http://localhost:8080/api/v1/account/" + accountNo, {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
            'Accept': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': 'true'
        }
    });

    try {
        return await res.json();
    }
    catch (error) {
        return null;
    }

}


export const depositAmount = async (data) => {
    //   console.log(data);
    const res = await fetch("http://localhost:8080/api/v1/account/deposit/", {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            'Accept': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify(data)
    });

    try {
        return await res.json();
    }
    catch (error) {
        return null;
    }

}

export const withdrawalAmount = async (data) => {
    //   console.log(data);
    const res = await fetch("http://localhost:8080/api/v1/account/withdrawal/", {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            'Accept': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify(data)
    });

    try {
        return await res.json();
    }
    catch (error) {
        return null;
    }

}

export const balanceEnquiry = async (accountNo) => {
    //   console.log(data);
    const res = await fetch("http://localhost:8080/api/v1/account/enquiry/" + accountNo);
    try {
        return await res.json();
    }
    catch (error) {
        return null;
    }

}

export const getMiniStatement = async (accountNo) => {
    //   console.log(data);
    const res = await fetch("http://localhost:8080/api/v1/transaction/" + accountNo);
    try {
        return await res.json();
    }
    catch (error) {
        return null;
    }

}



export const getCustomizeStatement = async (data) => {
    //   console.log(data);
    const res = await fetch("http://localhost:8080/api/v1/transaction/statement", {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            'Accept': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify(data)
    });

    try {
        return await res.json();
    }
    catch (error) {
        return null;
    }

}



export const transferFunds = async (data) => {
    //   console.log(data);
    const res = await fetch("http://localhost:8080/api/v1/account/fund_transfer", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            'Accept': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': 'true'
        },
        body: JSON.stringify(data)
    });

    try {
        return await res.json();
    }
    catch (error) {
        return null;
    }

}


export const accountsByUserId = async (customerId, accountType) => {
    //   console.log(data);
    const res = await fetch("http://localhost:8080/api/v1/account/customer/" + customerId + "-" + accountType);

    try {
        return await res.json();
    }
    catch (error) {
        return null;
    }

}

export const checkAccountsByUserId = async (customerId) => {
    //   console.log(data);
    const res = await fetch("http://localhost:8080/api/v1/account/check_customer/" + customerId);

    try {
        return await res.json();
    }
    catch (error) {
        return null;
    }

}