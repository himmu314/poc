import React, { useState } from 'react'
import { useNavigate } from "react-router-dom";
import { loginUser } from '../helpers/User';

export default function UserLoginFC(props) {

  let [username, setUsername] = useState('');
  let [password, setPassword] = useState('');
  let navigate = useNavigate();


  function userChange(e) {
    setUsername(e.target.value);
  }

  function passwordChange(e) {
    setPassword(e.target.value);
  }

  async function handleSubmit(e) {
    e.preventDefault()

    const data = await loginUser({ email: username, password: password });

    if (data !== null) {
      localStorage.setItem("id", data.userId)
      localStorage.setItem("name", data.userName)
      localStorage.setItem("userRole", data.userRole)

      if (data.userRole === "Manager")
        navigate("/managerdashboard")
      else
        navigate("/dashboard")
    }
    else {
      alert("User ID or Password is incorrect.\nPlease enter valid details.");
    }



  }


  return (
    <div className='container'>

      <form className='text-center mt-5' onSubmit={handleSubmit}>
        <div className='row justify-content-center'>
          <div className='col-10 col-md-7 col-lg-4 bg-light rounded p-2'>

            <h2 className='mb-4'>User Login</h2>

            <div className='mb-3'>
              <label className='form-label fw-bold'>Email</label>
              <input type='email' placeholder='Enter email' className='form-control' value={username} required onChange={userChange} />
            </div>
            <div className='mb-3'>
              <label className='form-label fw-bold'>Password</label>
              <input type='password' placeholder='Enter Password' className='form-control' required value={password} onChange={passwordChange} />
            </div>
            <div className='mb-3'>
              <input type='submit' className='btn btn-warning' value='Login' />
            </div>
          </div>
        </div>
      </form>

    </div>
  )



}



