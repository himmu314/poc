import React, { Component } from 'react'
import UserLoginFC from './UserLoginFC'
// import NavBar from '../NavBar'
import OuterNavBar from '../navigation/OuterNavBar'

export default class Login extends Component {
  render() {
    return (
      <div>
          <OuterNavBar />
          <UserLoginFC/>
      </div>
    )
  }
}
