import React, { useEffect } from 'react'
import { useState } from 'react'
import { accountById, updateAccount } from '../helpers/AccountHelper'
import ShowAccount from '../view_data/ShowAccount'

export default function EditAccount() {

  let [visible, setVisibile] = useState(false)
  let [accountNo, setAccountNo] = useState('')
  let [account, setAccount] = useState(null)
  let [accountData, setAccountData] = useState(null)
  let [savedData, setSavedData] = useState(false)



  useEffect(() => {
    if (accountData != null)
      setSavedData(true)
  }, [accountData])



  useEffect(() => {
    if (account != null)
      setVisibile(true)
  }, [account])

  async function findAccount(e) {
    e.preventDefault()

    var data = await accountById(accountNo)
    // console.log(data)

    if (data == null)
      alert("Invalid Account Number")
    else {
      setAccount(data)
    }

  }

  async function handleUpdatedData(e) {
    e.preventDefault()

    var data = await updateAccount(account)
    // console.log(data)
    if (data == null)
      alert("Invalid Customer ID")
    else {
      setAccountData(data)
    }
  }

  function defaultPage() {
    setAccount(null)
    setAccountData(null)
    setAccountNo('')
    setSavedData(false)
    setVisibile(false)
  }

  return (
    savedData ?
      <div>
        <div className='text-center text-success mb-3 mt-2'>
          <h4>Account Upadted Successfully</h4>
        </div>
        <ShowAccount setAccountData={accountData} />
        <button className='btn btn-success mt-4' onClick={defaultPage}>Update Other Customer</button>
      </div>
      :
      <div>

        <div className='row justify-content-md-center'>

          <div className='col-md-10 bg-light rounded'>

            <form onSubmit={findAccount} onReset={() => {
              setVisibile(false)
              setAccountNo('')
            }}>
              <div className='row gy-3'>

                <div className=' text-center text-success mb-4'>
                  <h3>Edit Account Details</h3>
                </div>

                <div className='col-md-6'>
                  <input type="text" placeholder='Enter Account No' className='form-control' onChange={
                    (e) => setAccountNo(e.target.value)
                  } required pattern='[0-9]{1,}' title='Enter Only Numbers' />
                </div>

                <div className='col-6 text-center'>
                  <div className='row'>
                    <div className='col-6'>
                      <input type="submit" className="btn btn-success" value="Submit" />
                    </div>
                    <div className='col-6'>
                      <input type="reset" className="btn btn-success" value="Reset" />
                    </div>
                  </div>
                </div>
              </div>
            </form>

            {
              visible ? <form className='row gy-2 mt-5 border p-2 pb-3 rounded' onSubmit={handleUpdatedData}>

                <div className='col-md-6'>
                  <label className='form-label'>Customer ID</label>
                  <input type="text" className='form-control' required value={account.customer.userId}
                    onChange={(e) => { setAccount({ ...account, customer: { userId: e.target.value } }) }} />
                </div>

                <div className='col-md-6'>
                  <label className='form-label'>Account Type</label>
                  <select className="form-select" aria-label="Default select example" required
                    defaultValue={account.accountType}
                    onChange={(e) => { setAccount({ ...account, accountType: e.target.value }) }} >
                    <option value="0" disabled>Choose Account Type</option>
                    <option value="Saving">Saving</option>
                    <option value="Current">Current</option>
                  </select>
                </div>

                <div className='col-md-12'>
                  <label className='form-label'>Balance</label>
                  <input type="text" className='form-control' required pattern='[0-9]{1,}' title='Enter Only Numbers'
                    value={account.amount}
                    onChange={(e) => { setAccount({ ...account, amount: e.target.value }) }} />
                </div>

                <div className='col-12 text-center mt-4'>
                  <input type="submit" className="btn btn-warning" value="Submit" />
                </div>
              </form>
                :
                null
            }

          </div>

        </div>

      </div>
  )


}
