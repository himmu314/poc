import React, { useState } from 'react'
import { depositAmount } from '../helpers/AccountHelper'

export default function Deposit() {

  let [deposit, setDeposit] = useState({
    accountNo: '',
    balance: '',
    description: ''
  })

  function resetDeposit() {
    setDeposit({
      accountNo: '',
      balance: '',
      description: ''
    })
  }

  async function handleSubmit(e) {
    e.preventDefault()

    let isDeposit = await depositAmount(deposit)
    if (isDeposit) {
      alert("Amount Deposit Successfully.")
      resetDeposit()
    }
    else
      alert("Invalid Account No.")

  }

  return (
    <div>

      <div className='row justify-content-md-center mt-5 pb-2'>
        <div className='col-md-6 bg-light rounded p-5'>

          <form onSubmit={handleSubmit}>
            <div className='row gy-3'>

              <div className=' text-center text-success mb-4'>
                <h3>Deposit</h3>
              </div>

              <div className='col-md-6'>
                <label className='form-label'>Account No</label>
                <input type="text" className='form-control' required pattern='[0-9]{1,}' title='Enter Only Numbers'
                  value={deposit.accountNo}
                  onChange={(e) => setDeposit({ ...deposit, accountNo: e.target.value })} />
              </div>

              <div className='col-md-6'>
                <label className='form-label'>Amount Deposit</label>
                <input type="text" className='form-control' required pattern='[0-9]{1,}' title='Enter Only Numbers'
                  value={deposit.balance}
                  onChange={(e) => setDeposit({ ...deposit, balance: e.target.value })} />
              </div>

              <div className='col-md-12 mb-3'>
                <label className='form-label'>Description</label>
                <textarea type="text" className='form-control' required
                  value={deposit.description}
                  onChange={(e) => setDeposit({ ...deposit, description: e.target.value })}></textarea>
              </div>


              <div className='col-6 text-center'>
                <input type="submit" className="btn btn-success" value="Submit" />
              </div>
              <div className='col-6 text-center'>
                <input type="reset" className="btn btn-success" value="Reset" onClick={resetDeposit} />
              </div>

            </div>
          </form>

        </div>
      </div>

    </div>
  )
}
