import React from 'react'
import ManagerNavBar from './ManagerNavBar'
import UserDetails from '../dasboard/UserDetails'
import { Link, Outlet } from 'react-router-dom'

export default function ManagerDashboard() {

  function logout() {
    localStorage.removeItem("id")
    localStorage.removeItem("name")
    localStorage.removeItem("userRole")
  }


  let Result = null


  const TRUE =
    <div className='mb-5'>
      <ManagerNavBar />
      <UserDetails />
      <Outlet />
    </div>

  const FALSE =
    <div className='text-center text-white mt-5'>
      <h1>
        You are not authorized to view this page.
      </h1>
      <p>Go To Login Page <Link to="/login" onClick={logout} >Click here...</Link></p>
    </div>

  if (localStorage.getItem("userRole") === "Manager")
    Result = TRUE
  else
    Result = FALSE

  return (

    Result
  )


}
