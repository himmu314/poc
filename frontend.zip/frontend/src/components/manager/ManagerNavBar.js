import React from 'react'
import { Navbar,Nav} from 'react-bootstrap'
import {Link, useLocation} from 'react-router-dom';
import logo from '../../images/logo1.png'
// import UserLoginCC from './login/UserLoginCC';


export default function ManagerNavBar() {
    
  let loc = useLocation('')
      
    return (
      <div>
                    <Navbar style={{backgroundColor: "rgb(20, 32, 84)"}} variant={"dark"} expand="lg" className='px-4'>
                        <Navbar.Brand >
                          <Nav.Link as={Link} to="home">
                          <img src={logo} alt='logo' style={{ width: "5rem" }} />
                          </Nav.Link>
                        </Navbar.Brand>
                        <Navbar className='ms-4'>
                            <h5 className='text-white'>XOR Bank</h5>
                          </Navbar>
                        <Navbar.Toggle aria-controls="navbarScroll" />
                        <Navbar.Collapse id="navbarScroll">
                            <Nav
                                className="ms-auto my-2 my-lg-0"
                                style={{ maxHeight: '100px' }}
                                navbarScroll
                            >
                                <Nav.Link  as={Link} className={loc.pathname==="/managerdashboard" || loc.pathname==="/managerdashboard/home" ? "active": "" } to="home" >Home</Nav.Link>
                               
                                <Nav.Link   as={Link} className={ loc.pathname==="/managerdashboard/user" ? "active": "" } to="user" > Profile </Nav.Link>

                                <Nav.Link   as={Link} className={ loc.pathname==="/managerdashboard/customer" ? "active": "" } to="customer" > Customer </Nav.Link>

                                <Nav.Link   as={Link} className={ loc.pathname==="/managerdashboard/account" ? "active": "" } to="account" > Account </Nav.Link>

                                <Nav.Link   as={Link} className={ loc.pathname==="/managerdashboard/deposit" ? "active": "" } to="deposit" > Deposit </Nav.Link>

                                <Nav.Link   as={Link} className={ loc.pathname==="/managerdashboard/withdrawal" ? "active": "" } to="withdrawal" > Withdrawal </Nav.Link>

                                <Nav.Link  as={Link} className={ loc.pathname==="/managerdashboard/balance" ? "active": "" } to="balance" > Balance Enquery </Nav.Link>
                                
                                <Nav.Link  as={Link} className={ loc.pathname==="/managerdashboard/statement" ? "active": "" } to="statement" >Account Statement </Nav.Link>

                                <Nav.Link  as={Link} className={ loc.pathname==="/managerdashboard/funds" ? "active": "" } to="funds" >Fund Transfer </Nav.Link>

                            </Nav>

                        </Navbar.Collapse>
                    </Navbar>
      </div>
    )
  
}
