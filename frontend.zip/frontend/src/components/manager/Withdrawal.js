import React, { useState } from 'react'
import { withdrawalAmount } from '../helpers/AccountHelper'

export default function Withdrawal() {

  let [withdrawal, setWithdrawal] = useState({
    accountNo: '',
    balance: '',
    description: ''
  })

  function resetWithdrawal() {
    setWithdrawal({
      accountNo: '',
      balance: '',
      description: ''
    })
  }

  async function handleSubmit(e) {
    e.preventDefault()

    let isWithdrawal = await withdrawalAmount(withdrawal)
    if (isWithdrawal) {
      alert("Amount Withdrawal Successfully.")
      resetWithdrawal()
    }
    else
      alert("Invalid Account No. OR Inssufient Balance")

  }

  return (
    <div>

      <div className='row justify-content-md-center mt-5 pb-2'>
        <div className='col-md-6 bg-light rounded p-5'>

          <form onSubmit={handleSubmit}>
            <div className='row gy-3'>

              <div className=' text-center text-success mb-4'>
                <h3>Withdrawal</h3>
              </div>

              <div className='col-md-6'>
                <label className='form-label'>Account No</label>
                <input type="text" className='form-control' required pattern='[0-9]{1,}' title='Enter Only Numbers'
                  value={withdrawal.accountNo}
                  onChange={(e) => setWithdrawal({ ...withdrawal, accountNo: e.target.value })} />
              </div>

              <div className='col-md-6'>
                <label className='form-label'>Amount</label>
                <input type="text" className='form-control' required pattern='[0-9]{1,}' title='Enter Only Numbers'
                  value={withdrawal.balance}
                  onChange={(e) => setWithdrawal({ ...withdrawal, balance: e.target.value })} />
              </div>

              <div className='col-md-12 mb-3'>
                <label className='form-label'>Description</label>
                <textarea type="text" className='form-control' required
                  value={withdrawal.description}
                  onChange={(e) => setWithdrawal({ ...withdrawal, description: e.target.value })}></textarea>
              </div>


              <div className='col-6 text-center'>
                <input type="submit" className="btn btn-success" value="Submit" />
              </div>
              <div className='col-6 text-center'>
                <input type="reset" className="btn btn-success" value="Reset" onClick={resetWithdrawal} />
              </div>

            </div>
          </form>

        </div>
      </div>


    </div>
  )
}
