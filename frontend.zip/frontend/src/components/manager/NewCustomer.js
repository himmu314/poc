import React, { useEffect, useState } from 'react'
import { addCustomer } from '../helpers/User'
import ShowCustomer from '../view_data/ShowCustomer'

export default function NewCustomer() {

  let [customer, setCustomer] = useState({
    userName: "",
    gender: "",
    dob: "",
    address: {
      streetName: "",
      city: "",
      pin: "",
      state: ""
    },
    telNo: "",
    email: "",
  })

  let [userData, setUserData] = useState(null)
  let [savedData, setSavedData] = useState(false)

  useEffect(() => {
    if (userData != null)
      setSavedData(true)
  }, [userData])


  function cleanForm() {
    setCustomer({
      userName: "",
      gender: "",
      dob: "",
      address: {
        streetName: "",
        city: "",
        pin: "",
        state: ""
      },
      telNo: "",
      email: "",
    })


    setUserData(null)
    setSavedData(false)

  }

  async function handleSubmit(e) {

    e.preventDefault()

    if (customer.gender === "")
      alert("Please Choose Gender.")
    else {
      let data = await addCustomer(customer)
      if (data == null)
        alert("Email is already registered.")
      else
        setUserData(data)
    }

  }

  return (
    savedData ?
      <div>
        <div className='text-center text-success mb-3 mt-2'>
          <h4>Customer Added Successfully</h4>
        </div>
        <ShowCustomer customerData={userData} updated={false} />
        <button className='btn btn-success mt-4' onClick={cleanForm}>Add New Customer</button>
      </div>
      :
      <div>

        <form className='row gy-2' onSubmit={handleSubmit}>
          <div className='text-center text-success mb-3 mt-2'>
            <h3>Add New Customer</h3>
          </div>

          <div className='col-md-6'>
            <label className='form-label'>Customer Name</label>
            <input type="text" className='form-control' required pattern='[a-zA-Z ]{1,}' title='Enter Only Charachter'
              onChange={(e) => setCustomer({ ...customer, userName: e.target.value })} />
          </div>

          <div className='col-md-6'>
            <label className='form-label'>Gender</label>
            <select className="form-select" aria-label="Default select example" required defaultValue="0"
              onChange={(e) => setCustomer({ ...customer, gender: e.target.value })} >
              <option value="0" disabled>Choose Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div className='col-md-12'>
            <label className='form-label'>Address</label>
            <textarea type="text" className='form-control' required
              onChange={(e) => setCustomer({ ...customer, address: { ...customer.address, streetName: e.target.value } })} ></textarea>
          </div>

          <div className='col-md-6'>
            <label className='form-label'>City</label>
            <input type="text" className='form-control' required
              onChange={(e) => setCustomer({ ...customer, address: { ...customer.address, city: e.target.value } })} />
          </div>

          <div className='col-md-6'>
            <label className='form-label'>State</label>
            <input type="text" className='form-control' required
              onChange={(e) => setCustomer({ ...customer, address: { ...customer.address, state: e.target.value } })} />
          </div>

          <div className='col-md-6'>
            <label className='form-label'>PIN</label>
            <input type="text" className='form-control' required pattern='[0-9]{1,}' title='Enter Only Numbers'
              onChange={(e) => setCustomer({ ...customer, address: { ...customer.address, pin: e.target.value } })} />
          </div>

          <div className='col-md-6'>
            <label className='form-label'>Telephone No</label>
            <input type="text" className='form-control' required pattern='[0-9]{1,10}' title='Enter Only Numbers'
              onChange={(e) => setCustomer({ ...customer, telNo: e.target.value })} />
          </div>

          <div className='col-md-6'>
            <label className='form-label'>Email ID</label>
            <input type="email" className='form-control' required
              onChange={(e) => setCustomer({ ...customer, email: e.target.value })} />
          </div>


          <div className='col-md-6'>
            <label className='form-label'>DOB</label>
            <input type="date" className='form-control' required
              onChange={(e) => setCustomer({ ...customer, dob: e.target.value })} />
          </div>

          <div className='col-6 text-center mt-4'>
            <input type="submit" className="btn btn-success" value="Submit" />
          </div>
          <div className='col-6 text-center mt-4'>
            <input type="reset" className="btn btn-warning" value="Reset" onClick={cleanForm} />
          </div>
        </form>
      </div>
  )
}
