import React, { useEffect, useState } from 'react'
import { customerById, updateCustomer } from '../helpers/User'
import ShowCustomer from '../view_data/ShowCustomer'

export default function EditCustomer() {

  let [visible, setVisibile] = useState(false)
  let [customerID, setcustomerID] = useState('')
  let [customer, setCustomer] = useState(null)
  let [userData, setUserData] = useState(null)
  let [savedData, setSavedData] = useState(false)


  useEffect(() => {
    if (userData != null)
      setSavedData(true)
  }, [userData])


  useEffect(() => {
    if (customer != null)
      setVisibile(true)
  }, [customer])

  async function findCustomer(e) {

    e.preventDefault()

    let data = await customerById(customerID)
    if (data === null) {
      alert(customerID + " is invalid Customer ID.")
      setcustomerID('')
      setVisibile(false)
    }
    else {
      setCustomer(data)
    }

  }


  async function handleSubmit(e) {
    e.preventDefault()

    // console.log(customer)

    let data = await updateCustomer(customer)
    setUserData(data)

  }



  function defaultPage() {
    setCustomer(null)
    setSavedData(false)
    setUserData(null)
    setVisibile(false)
    setcustomerID('')
  }

  return (
    savedData ?
      <div>
        <div className='text-center text-success mb-3 mt-2'>
          <h4>Customer Upadted Successfully</h4>
        </div>
        <ShowCustomer customerData={userData} updated={true} />
        <button className='btn btn-success mt-4' onClick={defaultPage}>Update Other Customer</button>
      </div>
      :
      <div>
        <div className='row justify-content-md-center'>

          <div className='col-md-11 bg-light rounded'>

            <form onSubmit={findCustomer} onReset={() => {
              setVisibile(false)
              setcustomerID('')
            }}>
              <div className='row gy-3'>

                <div className=' text-center text-success mb-2'>
                  <h3>Edit Customer Details</h3>
                </div>

                <div className='col-md-6'>
                  <input type="text" placeholder='Enter Customer ID' value={customerID} className='form-control' onChange={
                    (e) => setcustomerID(e.target.value)
                  } required />
                </div>

                <div className='col-6 text-center'>
                  <div className='row'>
                    <div className='col-6'>
                      <input type="submit" className="btn btn-success" value="Submit" />
                    </div>
                    <div className='col-6'>
                      <input type="reset" className="btn btn-success" value="Reset" />
                    </div>
                  </div>
                </div>
              </div>
            </form>

            {visible ?
              <form className='row gy-2 mt-5 border p-1 pb-3 rounded' onSubmit={handleSubmit} >

                <div className='col-md-6'>
                  <label className='form-label'>Customer Name</label>
                  <input type="text" className='form-control' required value={customer.userName}
                    onChange={(e) => { setCustomer({ ...customer, userName: e.target.value }) }} />
                </div>

                <div className='col-md-6'>
                  <label className='form-label'>Gender</label>
                  <select className="form-select" aria-label="Default select example" required defaultValue={customer.gender}
                    onChange={(e) => { setCustomer({ ...customer, gender: e.target.value }) }} >
                    <option value="0" disabled>Choose Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div className='col-md-12'>
                  <label className='form-label'>Address</label>
                  <textarea type="text" className='form-control' required value={customer.address.streetName}
                    onChange={(e) => { setCustomer({ ...customer, address: { ...customer.address, streetName: e.target.value } }) }}></textarea>
                </div>

                <div className='col-md-6'>
                  <label className='form-label'>City</label>
                  <input type="text" className='form-control' required value={customer.address.city}
                    onChange={(e) => { setCustomer({ ...customer, address: { ...customer.address, city: e.target.value } }) }} />
                </div>

                <div className='col-md-6'>
                  <label className='form-label'>State</label>
                  <input type="text" className='form-control' required value={customer.address.state}
                    onChange={(e) => { setCustomer({ ...customer, address: { ...customer.address, state: e.target.value } }) }} />
                </div>

                <div className='col-md-6'>
                  <label className='form-label'>PIN</label>
                  <input type="text" className='form-control' required pattern='[0-9]{1,}' title='Enter Only Numbers'
                    value={customer.address.pin}
                    onChange={(e) => { setCustomer({ ...customer, address: { ...customer.address, pin: e.target.value } }) }} />
                </div>

                <div className='col-md-6'>
                  <label className='form-label'>Telephone No</label>
                  <input type="text" className='form-control' required pattern='[0-9]{1,10}' title='Enter Only Numbers'
                    value={customer.telNo}
                    onChange={(e) => { setCustomer({ ...customer, telNo: e.target.value }) }} />
                </div>

                <div className='col-md-6'>
                  <label className='form-label'>Email ID</label>
                  <input type="email" className='form-control' required value={customer.email}
                    onChange={(e) => { setCustomer({ ...customer, email: e.target.value }) }} />
                </div>


                <div className='col-md-6'>
                  <label className='form-label'>DOB</label>
                  <input type="date" className='form-control' required value={customer.dob.substring(0, 10)}
                    onChange={(e) => { setCustomer({ ...customer, dob: e.target.value }) }} />
                </div>

                <div className='col-12 text-center mt-4'>
                  <input type="submit" className="btn btn-warning" value="update" />
                </div>
              </form>

              : null
            }

          </div>

        </div>

      </div>
  )
}
