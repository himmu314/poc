import React, { useState } from 'react'
import { deleteCustomer } from '../helpers/User'

export default function DeleteCustomer() {

    let [customerID, setCustomerID] = useState('')

    async function delCustomer(e) {
        e.preventDefault()

        let confirmDelete = window.confirm("Are you sure you want to DELETE Customer with CustomerID: " + customerID)
        if (confirmDelete) {
            var isDeleted = await deleteCustomer(customerID)

            if (isDeleted)
                alert("DELETED: CustomerId: " + customerID)
            else
                alert("ERROR: Invalid CustomerId " + customerID)
        }
        setCustomerID('')
    }

    return (
        <div>

            <div className='row justify-content-md-center mt-3 pb-2'>
                <div className='col-md-10'>

                    <form onSubmit={delCustomer} >
                        <div className='row gy-3'>

                            <div className=' text-center text-success mb-2'>
                                <h3>Remove Customer</h3>
                            </div>

                            <div className='col-md-6'>
                                <input type="text" placeholder='Enter Customer ID' className='form-control' onChange={
                                    (e) => setCustomerID(e.target.value)
                                } value={customerID} required pattern='[0-9]{1,}' title='Enter Only Numbers' />
                            </div>

                            <div className='col-6 text-center'>
                                <div className='row'>
                                    <div className='col-6'>
                                        <input type="submit" className="btn btn-success" value="Submit" />
                                    </div>
                                    <div className='col-6'>
                                        <input type="reset" className="btn btn-success" value="Reset" onClick={
                                            () => setCustomerID('')
                                        } />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>


        </div>
    )
}
