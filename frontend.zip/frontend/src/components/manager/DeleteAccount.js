import React from 'react'
import { useState } from 'react'
import { deleteAccount } from '../helpers/AccountHelper'

export default function DeleteAccount() {


    let [accountNo, setAccountNo] = useState('')

    async function delAccount(e) {
        e.preventDefault()

        let confirmDelete = window.confirm("Are you sure you want to DELETE Account with Account No: " + accountNo)
        if (confirmDelete) {
            var isDeleted = await deleteAccount(accountNo)

            if (isDeleted)
                alert("DELETED: Account No: " + accountNo)
            else
                alert("ERROR: Invalid Account No " + accountNo)
        }
        setAccountNo('')
    }

    return (
        <div>

            <div className='row justify-content-md-center mt-3 pb-2'>
                <div className='col-md-10'>

                    <form onSubmit={delAccount} >
                        <div className='row gy-3'>

                            <div className=' text-center text-success mb-4'>
                                <h3>Remove Account</h3>
                            </div>

                            <div className='col-md-6'>
                                <input type="text" placeholder='Enter Account No' className='form-control' onChange={
                                    (e) => setAccountNo(e.target.value)
                                } value={accountNo} required pattern='[0-9]{1,}' title='Enter Only Numbers' />
                            </div>

                            <div className='col-6 text-center'>
                                <div className='row'>
                                    <div className='col-6'>
                                        <input type="submit" className="btn btn-success" value="Submit" />
                                    </div>
                                    <div className='col-6'>
                                        <input type="reset" className="btn btn-success" value="Reset" onClick={
                                            () => setAccountNo('')
                                        } />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>


        </div>
    )

}
