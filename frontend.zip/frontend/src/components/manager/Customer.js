import React from 'react'
import DeleteCustomer from './DeleteCustomer'
import EditCustomer from './EditCustomer'
import NewCustomer from './NewCustomer'

export default function Customer() {

  return (
    <div className='container'>
        
      <div className='row justify-content-md-center mt-5'>

      <div className="col-md-8 bg-light p-4 rounded" style={{marginTop: "10px"}}>

      <ul className="nav nav-tabs">
        <li className="nav-item">
          <a className="nav-link active" data-bs-toggle="tab" href="#new">New Customer</a>
        </li>
        <li className="nav-item">
          <a className="nav-link" data-bs-toggle="tab" href="#edit">Edit Customer</a>
        </li>
        <li className="nav-item">
          <a className="nav-link" data-bs-toggle="tab" href="#del">Delete Customer</a>
        </li>
      </ul>


      <div className="tab-content">

        <div className="tab-pane container active px-5 py-3" id="new">
          <NewCustomer/>
        </div>

        <div className="tab-pane container px-5 py-3" id="edit">
          <EditCustomer/>
        </div>

        <div className="tab-pane container fade" id="del">
          <DeleteCustomer/>
        </div>

      </div>
      </div>

    </div>

    </div>
  )

}
