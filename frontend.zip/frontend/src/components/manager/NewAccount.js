import React, { useEffect, useState } from 'react'
import { addAccount } from '../helpers/AccountHelper'
import ShowAccount from '../view_data/ShowAccount'

export default function NewAccount() {

  let [account, setAccount] = useState({
    accountNo: 0,
    accountType: '',
    amount: 0,
    customer: {
      userId: 0
    },
    manager: {
      userId: localStorage.getItem("id")
    }
  })

  let [accountData, setAccountData] = useState(null)
  let [savedData, setSavedData] = useState(false)

  useEffect(() => {
    if (accountData != null)
      setSavedData(true)
  }, [accountData])


  async function handleSubmit(e) {
    e.preventDefault()

    if (account.accountType === '0')
      alert("Please choose the Account Type.")
    else {
      // console.log(account)
      var data = await addAccount(account)

      if (data == null) {
        alert("Invalid Customer ID.")
      }
      else {
        setAccountData(data)
        // console.log(data)
      }

    }

  }

  function cleanForm() {
    setAccount(null)
    setAccountData(null)
    setSavedData(false)
  }


  return (
    savedData ?
      <div>
        <div className='text-center text-success mb-3 mt-2'>
          <h4>Account Added Successfully</h4>
        </div>
        <ShowAccount setAccountData={accountData} />
        <button className='btn btn-success mt-4' onClick={cleanForm}>Add New Account</button>
      </div>
      :
      <div>
        <form className='row gy-2' onSubmit={handleSubmit}>
          <div className='text-center text-success mb-3 mt-2'>
            <h3>Add New Account</h3>
          </div>

          <div className='col-md-6'>
            <label className='form-label'>Customer ID</label>
            <input type="text" className='form-control' required
              onChange={(e) => setAccount({ ...account, customer: { userId: e.target.value } })} />
          </div>

          <div className='col-md-6'>
            <label className='form-label'>Account Type</label>
            <select className="form-select" aria-label="Default select example" required defaultValue="0"
              onChange={(e) => setAccount({ ...account, accountType: e.target.value })}>
              <option value="0" disabled>Choose Account Type</option>
              <option value="Saving">Saving</option>
              <option value="Current">Current</option>
            </select>
          </div>

          <div className='col-md-12'>
            <label className='form-label'>Initial Deposit</label>
            <input type="text" className='form-control' required pattern='[0-9]{1,}' title='Enter Only Numbers'
              onChange={(e) => setAccount({ ...account, amount: e.target.value })} />
          </div>

          <div className='col-6 text-center mt-4'>
            <input type="submit" className="btn btn-success" value="Submit" />
          </div>
          <div className='col-6 text-center mt-4'>
            <input type="reset" className="btn btn-warning" value="Reset" onClick={cleanForm} />
          </div>
        </form>
      </div>
  )
}
