import React from 'react'

export default function ShowCustomer({ customerData, updated }) {

    let userAddress = customerData.address.streetName + ", " + customerData.address.city + ", " +
        customerData.address.state + ", " + customerData.address.pin

    return (
        <div>

            <div className='row justify-content-center'>
                <div className='col-5'><strong>Customer ID</strong></div>
                <div className='col-2'><strong>:</strong></div>
                <div className='col-5'>{customerData.userId}</div>
            </div>
            <div className='row justify-content-center'>
                <div className='col-5'><strong>Customer Name</strong></div>
                <div className='col-2'><strong>:</strong></div>
                <div className='col-5'>{customerData.userName}</div>
            </div>
            <div className='row justify-content-center'>
                <div className='col-5'><strong>Gender</strong></div>
                <div className='col-2'><strong>:</strong></div>
                <div className='col-5'>{customerData.gender}</div>
            </div>
            <div className='row justify-content-center'>
                <div className='col-5'><strong>DOB</strong></div>
                <div className='col-2'><strong>:</strong></div>
                <div className='col-5'>{customerData.dob.substring(0, 10)}</div>
            </div>
            <div className='row justify-content-center'>
                <div className='col-5'><strong>Email</strong></div>
                <div className='col-2'><strong>:</strong></div>
                <div className='col-5'>{customerData.email}</div>
            </div>
            <div className='row justify-content-center'>
                <div className='col-5'><strong>Telephone</strong></div>
                <div className='col-2'><strong>:</strong></div>
                <div className='col-5'>{customerData.telNo}</div>
            </div>

            {
                updated !== true ?
                    <div className='row justify-content-center'>
                        <div className='col-5'><strong>Password</strong></div>
                        <div className='col-2'><strong>:</strong></div>
                        <div className='col-5'>{customerData.password}</div>
                    </div>
                    :
                    null
            }

            <div className='row justify-content-center'>
                <div className='col-5'><strong>Address</strong></div>
                <div className='col-2'><strong>:</strong></div>
                <div className='col-5'>{userAddress}</div>
            </div>

        </div>
    )
}
