import React from 'react'

export default function ShowAccount({ setAccountData }) {
    return (
        <div>

            <div className='row justify-content-center'>
                <div className='col-5'><strong>Account No</strong></div>
                <div className='col-2'><strong>:</strong></div>
                <div className='col-5'>{setAccountData.accountNo}</div>
            </div>
            <div className='row justify-content-center'>
                <div className='col-5'><strong>Account Type</strong></div>
                <div className='col-2'><strong>:</strong></div>
                <div className='col-5'>{setAccountData.accountType}</div>
            </div>
            <div className='row justify-content-center'>
                <div className='col-5'><strong>Balance</strong></div>
                <div className='col-2'><strong>:</strong></div>
                <div className='col-5'>{setAccountData.amount}</div>
            </div>
            <div className='row justify-content-center'>
                <div className='col-5'><strong>Customer ID: </strong></div>
                <div className='col-2'><strong>:</strong></div>
                <div className='col-5'>{setAccountData.customer.userId}</div>
            </div>
            <div className='row justify-content-center'>
                <div className='col-5'><strong>Manager ID</strong></div>
                <div className='col-2'><strong>:</strong></div>
                <div className='col-5'>{setAccountData.manager.userId}</div>
            </div>

        </div>
    )
}
