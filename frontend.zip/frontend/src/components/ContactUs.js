import React from 'react'
import OuterNavBar from './navigation/OuterNavBar'

export default function ContactUs() {
  return (
    <div>

        <OuterNavBar/>

        <div className='container p-3 mt-5'>
            <div className='row justify-content-center'>
                <div className='col-md-6'>
                    <form className='row gy-4 text-white'>

                    <h3 className='text-warning text-center fw-bold'>Contact Us</h3>

                    <div className='col-md-12'>
                        <label className='form-label'>Name</label>
                        <input type="text" className='form-control' required pattern='[a-zA-Z ]{1,}' title='Enter Only Charachter' />
                    </div>

                    <div className='col-md-12'>
                        <label className='form-label'>Mobile No</label>
                        <input type="text" className='form-control' required pattern='[0-9]{1,10}' title='Enter Only Numbers' />
                    </div>

                    <div className='col-md-12'>
                        <label className='form-label'>Email ID</label>
                        <input type="email" className='form-control' required  />
                    </div>

                    
                        <div className='col-6 text-center mt-4'>
                        <input type="submit" className="btn btn-success" value="Submit" />
                        </div>
                        <div className='col-6 text-center mt-4'>
                        <input type="reset" className="btn btn-warning" value="Reset" />
                        </div>
                </form>
            </div>
           </div>

        </div>

    </div>
  )
}
